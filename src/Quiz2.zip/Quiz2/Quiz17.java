package Quiz2;


import java.util.ArrayList;
import java.util.Collection;

class Quiz2{
    public static void main(String[] args) {

        Integer[] nums = { 11, 22, 25, 15, 15,15, 11};
        String[] names = { "Lakers", "Bucks", "Bulls", "Bulls", "Nets", "Warriors", "Lakers" };

        ArrayList<Integer> list = new ArrayList< >();
        fromArrayToCollection(nums, list);


        System.out.println("original Integer list" + list);
        ArrayList<Integer> newList = removeDuplicates(list);
        ArrayList<Integer> newList1 = removeDuplicates(list);

        System.out.print("nodup  list " + newList);

        ArrayList<String> nameList = new ArrayList<>();
        fromArrayToCollection(names, nameList);
        System.out.println("\n\nSame method for the name list");


        System.out.println("original list" + nameList);
        System.out.println("nodup list" + removeDuplicates(nameList));

    }


    //write codes here for static method to return both the dup and non-dup arrau
    public static <E> ArrayList<E> removeDuplicates(ArrayList<E> list) {
        ArrayList<E> result = new ArrayList<E>();
        ArrayList<E> result1 = new ArrayList<E>();

        for (E e: list) {
            if (!result1.contains(e))
                result1.add(e);
            else
                result.add(e);
        }
        return result1;
    }

    ArrayList<E> newList = new ArrayList<>();
        for (int i = 0;i<list.size();++i){
        if (!newList.contains(list.get(i))){
            newList.add(list.get(i));
        }
    }
        return newList;
}

    public static <T> void fromArrayToCollection(T a[], Collection<T> c) {
        for (T x: a)
            c.add(x);
    }
}
